from pathlib import Path
p=Path('apps/web/src/lib/clips.test.ts');s=p.read_text().replace('import { isClipCursor, mergeClipItems, parseClipsPage, type ClipItem } from "./clips";', 'import { createClipsAutoplayGate, isClipCursor, mergeClipItems, parseClipsPage, type ClipItem } from "./clips";');s+='''

describe("Clips autoplay after audience restoration", () => {
  it("preserves the deliberate active pause, then autoplays an offscreen Clip and a return visit", () => {
    const autoplay = createClipsAutoplayGate({
      activeId: "current",
      playback: { current: { paused: true }, offscreen: { paused: true } },
    });
    expect(autoplay("current", true, false)).toBe(false);
    // Repeated intersection notifications or a pagination observer rebuild
    // must not undo the currently restored viewer's deliberate pause.
    expect(autoplay("current", true, false)).toBe(false);
    expect(autoplay("offscreen", true, false)).toBe(true);
    expect(autoplay("current", true, false)).toBe(true);
    expect(autoplay("offscreen", true, false)).toBe(true);
  });

  it("does not infer a deliberate pause from inactive media or missing state", () => {
    const autoplay = createClipsAutoplayGate({
      activeId: "current",
      playback: { current: { paused: false }, offscreen: { paused: true } },
    });
    expect(autoplay("current", true, false)).toBe(true);
    expect(autoplay("offscreen", true, false)).toBe(true);
    expect(createClipsAutoplayGate()("new", true, false)).toBe(true);
  });

  it("still honors disabled autoplay and reduced motion after moving away", () => {
    const autoplay = createClipsAutoplayGate({
      activeId: "current",
      playback: { current: { paused: true }, offscreen: { paused: true } },
    });
    expect(autoplay("offscreen", false, false)).toBe(false);
    expect(autoplay("offscreen", true, true)).toBe(false);
    expect(autoplay("current", true, true)).toBe(false);
    expect(autoplay("current", true, false)).toBe(true);
  });
});
''';p.write_text(s)
