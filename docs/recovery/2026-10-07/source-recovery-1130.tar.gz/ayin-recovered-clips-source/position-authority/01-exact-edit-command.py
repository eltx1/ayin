from pathlib import Path
p=Path('apps/web/src/lib/clips.ts');s=p.read_text();s+='''

export interface ClipPlaybackPosition {
  positionMs: number | undefined;
  paused: boolean;
  muted: boolean;
  volume: number;
  playbackRate: number;
}

export type RegisterClipPositionAuthority = (
  videoId: string,
  isPositionAuthoritative: () => boolean,
) => () => void;

export function captureClipPlaybackPosition(
  media: Pick<HTMLVideoElement, "readyState" | "currentTime" | "paused" | "muted" | "volume" | "playbackRate">,
  positionAuthoritative: boolean,
): ClipPlaybackPosition {
  return {
    // Metadata at zero does not establish a viewing position while the saved
    // progress read is still pending. Its provenance comes from useWatchProgress.
    positionMs: positionAuthoritative && media.readyState >= 1 && Number.isFinite(media.currentTime)
      ? Math.max(0, Math.floor(media.currentTime * 1000))
      : undefined,
    paused: media.paused,
    muted: media.muted,
    volume: media.volume,
    playbackRate: media.playbackRate,
  };
}
''';p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clip-video.tsx');s=p.read_text().replace('import type { ClipItem } from "@/lib/clips";', 'import type { ClipItem, ClipPlaybackPosition, RegisterClipPositionAuthority } from "@/lib/clips";');a=s.index('export interface ClipPlaybackPosition {');b=s.index('export function ClipVideo(',a);s=s[:a]+s[b:];s=s.replace('''  initialPlayback,
}: {''','''  initialPlayback,
  registerPositionAuthority,
}: {''');s=s.replace('''  initialPlayback?: ClipPlaybackPosition | undefined;
}) {''','''  initialPlayback?: ClipPlaybackPosition | undefined;
  registerPositionAuthority?: RegisterClipPositionAuthority | undefined;
}) {''');s=s.replace('''const { applyResume, markNativeSeek, finishNativeSeek, persist } = useWatchProgress''','''const { applyResume, markNativeSeek, finishNativeSeek, persist, isPositionAuthoritative } = useWatchProgress''');a=s.index('  const playbackRestored = useRef(false);');s=s[:a]+'''  useLayoutEffect(
    () => registerPositionAuthority?.(clip.id, isPositionAuthoritative),
    [clip.id, isPositionAuthoritative, registerPositionAuthority],
  );

'''+s[a:];p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clips-feed.tsx');s=p.read_text().replace('  type ClipItem,','  type ClipItem,\n  type ClipPlaybackPosition,\n  type RegisterClipPositionAuthority,');s=s.replace('import { ClipVideo, type ClipPlaybackPosition } from "./clip-video";', 'import { ClipVideo } from "./clip-video";');s=s.replace('''  initialPosition,
  onPageLoaded,
}: {''','''  initialPosition,
  onPageLoaded,
  registerPositionAuthority,
}: {''');s=s.replace('''  onPageLoaded?: ((cursor: string) => void) | undefined;
}) {''','''  onPageLoaded?: ((cursor: string) => void) | undefined;
  registerPositionAuthority?: RegisterClipPositionAuthority | undefined;
}) {''');s=s.replace('''                  initialPlayback={initialPosition?.playback[clip.id]}
''','''                  initialPlayback={initialPosition?.playback[clip.id]}
                  registerPositionAuthority={registerPositionAuthority}
''');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clips-client.tsx');s=p.read_text().replace('import { mergeClipItems, type ClipsPage } from "@/lib/clips";', 'import { captureClipPlaybackPosition, mergeClipItems, type ClipsPage, type RegisterClipPositionAuthority } from "@/lib/clips";');s=s.replace('  const root = useRef<HTMLDivElement>(null);','''  const root = useRef<HTMLDivElement>(null);
  const positionAuthority = useRef(new Map<string, () => boolean>());
  const registerPositionAuthority = useCallback<RegisterClipPositionAuthority>((videoId, check) => {
    positionAuthority.current.set(videoId, check);
    return () => {
      if (positionAuthority.current.get(videoId) === check) positionAuthority.current.delete(videoId);
    };
  }, []);''');a=s.index('                playback[id] = {');b=s.index('\n            });',a);s=s[:a]+'''                playback[id] = captureClipPlaybackPosition(
                  video,
                  positionAuthority.current.get(id)?.() === true,
                );'''+s[b:];s=s.replace('''        onPageLoaded={onPageLoaded}
''','''        onPageLoaded={onPageLoaded}
        registerPositionAuthority={registerPositionAuthority}
''');p.write_text(s)
p=Path('apps/web/src/lib/clips.test.ts');s=p.read_text().replace('  createClipsAutoplayGate,','  createClipsAutoplayGate,\n  captureClipPlaybackPosition,');s+='''

describe("Clips retention position provenance", () => {
  const media = { readyState: 4, currentTime: 0, paused: true, muted: false, volume: 0.4, playbackRate: 1.25 };
  it("keeps metadata-ready zero out of explicit restore while a progress read is pending", () => {
    expect(captureClipPlaybackPosition(media, false)).toEqual({ positionMs: undefined, paused: true, muted: false, volume: 0.4, playbackRate: 1.25 });
  });
  it("retains an authoritative explicit zero and a verified saved position", () => {
    expect(captureClipPlaybackPosition(media, true).positionMs).toBe(0);
    expect(captureClipPlaybackPosition({ ...media, currentTime: 7.25 }, true).positionMs).toBe(7_250);
  });
  it("requires media readiness even when the progress owner established a position", () => {
    expect(captureClipPlaybackPosition({ ...media, readyState: 0 }, true).positionMs).toBeUndefined();
  });
});
''';p.write_text(s)
