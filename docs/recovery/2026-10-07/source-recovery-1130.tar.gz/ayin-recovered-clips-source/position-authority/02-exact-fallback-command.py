from pathlib import Path
p=Path('apps/web/src/lib/clips.ts');s=p.read_text().replace('''  positionAuthoritative: boolean,
): ClipPlaybackPosition''','''  positionAuthoritative: boolean,
  previousPositionMs?: number,
): ClipPlaybackPosition''');s=s.replace('''        : undefined,
    paused: media.paused,''','''        : previousPositionMs,
    paused: media.paused,''');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clips-client.tsx');s=p.read_text().replace('''                  positionAuthority.current.get(id)?.() === true,
                );''','''                  positionAuthority.current.get(id)?.() === true,
                  retention.current?.position?.playback[id]?.positionMs,
                );''');s=s.replace('''      retention.current = { owner, cursors, isKids: page.viewer.isKids };''','''      retention.current = {
        owner,
        cursors,
        isKids: page.viewer.isKids,
        ...(sameAudience && retained.position ? { position: retained.position } : {}),
      };''');p.write_text(s)
p=Path('apps/web/src/lib/clips.test.ts');s=p.read_text();s+='''
it("preserves a prior verified Clip position while replacement media awaits resume", () => {
  const media = { readyState: 4, currentTime: 0, paused: true, muted: true, volume: 1, playbackRate: 1 };
  expect(captureClipPlaybackPosition(media, false, 7_000).positionMs).toBe(7_000);
  expect(captureClipPlaybackPosition(media, true, 7_000).positionMs).toBe(0);
});
''';p.write_text(s)
