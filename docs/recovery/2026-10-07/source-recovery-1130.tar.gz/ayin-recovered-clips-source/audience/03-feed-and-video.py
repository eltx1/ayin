from pathlib import Path
p=Path('apps/web/src/app/(viewer)/clips/clips-feed.tsx');s=p.read_text().replace('mergeClipItems, parseClipsPage, type ClipItem, type ClipsPage','mergeClipItems, type ClipItem, type ClipsPage');s=s.replace('import { translateClips }', 'import { ClipsReadError, readClips } from "@/lib/clips-request";\nimport { translateClips }');s=s.replace('import { ClipVideo } from "./clip-video";', 'import { ClipVideo, type ClipPlaybackPosition } from "./clip-video";');a=s.index('export function ClipsFeed(');b=s.index('  const { locale, href }',a);s=s[:a]+'''export interface ClipsPosition {
  scrollTop: number;
  activeId: string | null;
  playback: Record<string, ClipPlaybackPosition>;
}

export function ClipsFeed({
  initialPage,
  initialPosition,
  onPageLoaded,
}: {
  initialPage: ClipsPage;
  initialPosition?: ClipsPosition | undefined;
  onPageLoaded?: ((cursor: string) => void) | undefined;
}) {
  const { identity, isAudienceCurrent, onAudienceInvalidated, retryNavigation } = useViewerProduct();
  const continuation = useRef<AbortController | null>(null);
  const startingId = initialPage.items.some((item) => item.id === initialPosition?.activeId)
    ? initialPosition!.activeId
    : (initialPage.items[0]?.id ?? null);
'''+s[b:];s=s.replace('useRef<string | null>(initialPage.items[0]?.id ?? null)','useRef<string | null>(startingId)').replace('useState<string | null>(initialPage.items[0]?.id ?? null)','useState<string | null>(startingId)');a=s.index('  useEffect(() => {',s.index('export function ClipsFeed'));s=s[:a]+'''  useLayoutEffect(() => {
    if (root.current && initialPosition) root.current.scrollTop = initialPosition.scrollTop;
    const stop = onAudienceInvalidated(() => continuation.current?.abort());
    return () => {
      continuation.current?.abort();
      stop();
    };
  }, [initialPosition, onAudienceInvalidated]);

'''+s[a:];s=s.replace('      (entries) => {\n        for', '      (entries) => {\n        if (!isAudienceCurrent()) return;\n        for');s=s.replace('            if (autoplayEnabled && !window.matchMedia', '''            const retained = initialPosition?.playback[videoId];
            if (
              autoplayEnabled &&
              retained?.paused !== true &&
              !window.matchMedia''').replace('("(prefers-reduced-motion: reduce)").matches) {','("(prefers-reduced-motion: reduce)").matches\n            ) {',1);s=s.replace('  }, [autoplayEnabled, items.length]);','  }, [autoplayEnabled, initialPosition, isAudienceCurrent, items.length]);');a=s.index('  async function loadMore() {');b=s.index('\n  function moveByKeyboard',a);s=s[:a]+'''  async function loadMore() {
    if (!nextCursor || continuation.current || !isAudienceCurrent()) return;
    const cursor = nextCursor;
    const run = new AbortController();
    continuation.current = run;
    const valid = () => continuation.current === run && !run.signal.aborted && isAudienceCurrent();
    const deadline = window.setTimeout(() => run.abort(), 15000);
    setLoadMorePending(true);
    setLoadMoreError(false);
    try {
      const page = await readClips(cursor, { identity, isCurrent: isAudienceCurrent }, run.signal);
      if (!valid()) return;
      if (!page.enabled || page.viewer.isKids !== initialPage.viewer.isKids)
        throw new ClipsReadError(409);
      setItems((current) => mergeClipItems(current, page.items));
      setNextCursor(page.nextCursor);
      setAutoplayEnabled(page.autoplayEnabled);
      setAdPolicy(page.adPolicy);
      onPageLoaded?.(cursor);
    } catch (error) {
      if (continuation.current !== run || !isAudienceCurrent()) return;
      setLoadMoreError(true);
      if (error instanceof ClipsReadError && [401, 409].includes(error.status)) retryNavigation();
    } finally {
      window.clearTimeout(deadline);
      if (continuation.current === run) {
        continuation.current = null;
        if (isAudienceCurrent()) setLoadMorePending(false);
      }
    }
  }
'''+s[b:];s=s.replace('    if (event.target !== event.currentTarget) return;','    if (!isAudienceCurrent() || event.target !== event.currentTarget) return;');s=s.replace('<div ref={root} className={styles.feed}', '<div ref={root} data-clips-feed className={styles.feed}');s=s.replace('              data-clip-index={index}', '              data-clip-index={index}\n              data-clip-active={activeId === clip.id}');s=s.replace('<ClipVideo clip={clip} sourceUrl={sourceUrl} />','<ClipVideo\n                  clip={clip}\n                  sourceUrl={sourceUrl}\n                  initialPlayback={initialPosition?.playback[clip.id]}\n                />');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clip-video.tsx');s=p.read_text();a=s.index('export function ClipVideo(');b=s.index('  const videoRef',a);s=s[:a]+'''export interface ClipPlaybackPosition {
  positionMs: number | undefined;
  paused: boolean;
  muted: boolean;
  volume: number;
  playbackRate: number;
}

export function ClipVideo({ clip, sourceUrl, initialPlayback }: {
  clip: ClipItem;
  sourceUrl: string;
  initialPlayback?: ClipPlaybackPosition | undefined;
}) {
'''+s[b:];s=s.replace('    isIdentityCurrent,','    isIdentityCurrent,\n    isAudienceCurrent,',1);s=s.replace('    initialPositionMs: 0,','    initialPositionMs: initialPlayback?.positionMs ?? 0,\n    initialPositionExplicit: initialPlayback?.positionMs !== undefined,');a=s.index('  useEffect(() => {');s=s[:a]+'''  const playbackRestored = useRef(false);
  const ready = () => {
    if (!isAudienceCurrent()) return;
    applyResume();
    const video = videoRef.current;
    if (!video || playbackRestored.current || !initialPlayback || video.readyState < 1) return;
    playbackRestored.current = true;
    video.volume = initialPlayback.volume;
    video.playbackRate = initialPlayback.playbackRate;
    if (!initialPlayback.paused) void video.play().catch(() => undefined);
  };

'''+s[a:];s=s.replace('      muted\n','      muted={initialPlayback?.muted ?? true}\n');s=s.replace('onLoadedMetadata={applyResume}', 'onLoadedMetadata={ready}').replace('onCanPlay={applyResume}', 'onCanPlay={ready}');s=s.replace('      onPlay={(event) => {\n', '      onPlay={(event) => {\n        if (!isAudienceCurrent()) {\n          releaseHtmlMediaElement(event.currentTarget);\n          return;\n        }\n');p.write_text(s)
