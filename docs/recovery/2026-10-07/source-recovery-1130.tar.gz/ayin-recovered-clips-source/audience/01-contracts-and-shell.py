from pathlib import Path
p=Path('apps/web/src/lib/clips.ts');s=p.read_text().replace('export interface ClipsPage {\n', 'export interface ClipsPage {\n  viewer: { isKids: boolean };\n');s=s.replace('  const adPolicy = record(page.adPolicy);','  const adPolicy = record(page.adPolicy);\n  const viewer = record(page.viewer);');s=s.replace('    typeof page.enabled !== "boolean" ||', '    typeof viewer.isKids !== "boolean" ||\n    (viewer.isKids && adPolicy.enabled !== false) ||\n    typeof page.enabled !== "boolean" ||');s=s.replace('    enabled: page.enabled,','    viewer: { isKids: viewer.isKids },\n    enabled: page.enabled,');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/page.tsx');s=p.read_text().replace('import { ActionLink, PageHeader }','import { PageHeader }');s=s.replace('import { EmptyState, ErrorState } from "@/components/viewer/view-states";\n','').replace('import { fetchClipsPage } from "@/lib/clips-server";\n','').replace('import { localizePath } from "@/lib/i18n/routing";\n','').replace('import { ClipsFeed } from "./clips-feed";','import { ClipsClient } from "./clips-client";');a=s.index('  const path = localizePath');b=s.index('\n  return (',a);s=s[:a]+s[b:];a=s.index('      {!page ? (');b=s.index('\n    </main>',a);s=s[:a]+'      <ClipsClient />'+s[b:];p.write_text(s)
p=Path('apps/web/src/app/api/clips/route.ts');s=p.read_text().replace('import { fetchClipsPage } from "@/lib/clips-server";\n','');a=s.index('  try {');s=s[:a]+'''  // The browser must read the API with its own scoped credentials. Forwarding
  // an anonymous server fetch here can expose adult sources to a Kids session.
  return NextResponse.json(
    { error: { code: "CLIPS_DIRECT_READ_REQUIRED", message: "Reload Clips to continue." } },
    { status: 410, headers: { "cache-control": "private, no-store" } },
  );
}
''';p.write_text(s)
Path('apps/web/src/lib/clips-server.ts').unlink()
for file in ['apps/web/src/lib/clips.test.ts','apps/web/src/app/(viewer)/clips/clips-feed.test.tsx']:
 p=Path(file);s=p.read_text().replace('  enabled: true,','  viewer: { isKids: false },\n  enabled: true,');p.write_text(s)
