from pathlib import Path
p=Path('apps/web/src/app/(viewer)/clips/clips-client.tsx');s=p.read_text().replace('  if (!current.page.items.length)\n', '  if (!current.page.items.length && !current.page.nextCursor)\n');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clips-feed.tsx');s=p.read_text().replace('import { useViewerProduct } from "@/components/viewer/viewer-product-context";', 'import { useViewerProduct } from "@/components/viewer/viewer-product-context";\nimport { EmptyState } from "@/components/viewer/view-states";');s=s.replace('''      <div ref={root} data-clips-feed className={styles.feed} aria-label={t("clips.feed")}>''','''      {!items.length ? <EmptyState title={t("clips.emptyTitle")} description={t("clips.emptyDescription")} /> : null}
      <div ref={root} hidden={!items.length} data-clips-feed className={styles.feed} aria-label={t("clips.feed")}>''');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clips-feed.test.tsx');s=p.read_text();s+='''\n// A final policy/asset recheck may remove all items in a selected page while
// preserving a continuation anchor. The next allowed page must stay reachable.
it("keeps pagination reachable when final revalidation removes a whole page", () => {
  const html = renderToStaticMarkup(
    <I18nProvider locale="en">
      <ClipsFeed initialPage={{ ...page, items: [], nextCursor: "00000000-0000-4000-8000-000000000001" }} />
    </I18nProvider>,
  );
  expect(html).toContain('data-tv-focus-id="clips-load-more"');
  expect(html).toContain(translateClips("en", "clips.emptyTitle"));
  expect(html).not.toContain("<video");
});
''';p.write_text(s)
