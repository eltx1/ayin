from pathlib import Path
p=Path('apps/web/src/app/(viewer)/clips/clips-client.tsx');s=p.read_text().replace('    retention.current = null;\n    const run', '    if (!retained) retention.current = null;\n    const run');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clips-feed.tsx');s=p.read_text().replace('''.then(() =>
                  trackAnalyticsEvent("CLIP_PLAY", {
                    videoId,
                    ...(channelId ? { channelId } : {}),
                  }),
                )''','''.then(() => {
                  if (isAudienceCurrent())
                    trackAnalyticsEvent("CLIP_PLAY", {
                      videoId,
                      ...(channelId ? { channelId } : {}),
                    });
                })''');p.write_text(s)
p=Path('apps/web/src/app/(viewer)/clips/clip-video.tsx');s=p.read_text().replace('      onEnded={() => {\n        void persist(true);','      onEnded={() => {\n        if (!isAudienceCurrent()) return;\n        void persist(true);');p.write_text(s)
p=Path('tests/e2e/clips-viewer-audience.acceptance.spec.ts');s=p.read_text();marker='for (const phase of ["initial", "continuation"] as const)';a=s.index(marker);b=s.index('test("same verified',a);block=s[a:b].replace('    let captured = false;','    let captured = false;\n    let delivered = false;');block=block.replace('      await route.fulfill({ response: actual }).catch(() => undefined);','      await route.fulfill({ response: actual }).catch(() => undefined);\n      delivered = true;');block=block.replace('      gate.release();\n      await expect(article', '''      gate.release();
      await expect.poll(() => delivered).toBe(true);
      await page.evaluate(() => new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve()))));
      await expect(article''');s=s[:a]+block+s[b:];p.write_text(s)
