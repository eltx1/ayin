from pathlib import Path
p=Path('apps/web/src/app/(viewer)/clips/clips-feed.tsx');s=p.read_text().replace('data-clip-impressed={impressed.current.has(clip.id)}','data-clip-impressed={initialPosition?.impressedIds.includes(clip.id) ?? false}');p.write_text(s)
