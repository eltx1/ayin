
async function holdProgressRead(page: Page, videoId: string, ordinal: number) {
  let count = 0;
  let received!: (response: APIResponse) => void;
  let release!: () => void;
  let finished!: () => void;
  const response = new Promise<APIResponse>((resolve) => { received = resolve; });
  const held = new Promise<void>((resolve) => { release = resolve; });
  const done = new Promise<void>((resolve) => { finished = resolve; });
  await page.route(`${API}/watch/progress/${videoId}*`, async (route) => {
    if (route.request().method() !== "GET" || ++count !== ordinal) return route.continue();
    try {
      const actual = await route.fetch();
      received(actual);
      await held;
      await route.fulfill({ response: actual }).catch((error: Error) => {
        if (!/aborted|Invalid InterceptionId|already handled|Target.*closed/i.test(error.message)) throw error;
      });
    } finally { finished(); }
  });
  return { response, release, done };
}
async function seedSavedPosition(page: Page, catalog: Catalog, positionMs: number) {
  const response = await page.request.put(`${API}/watch/progress/${catalog.videos.adult.id}`, {
    headers: { origin: WEB, "x-ayin-expected-account": catalog.accountId },
    data: { profileId: catalog.profileId, positionMs, durationMs: 120000 },
  });
  expect(response.status()).toBe(200);
}

test("metadata-ready zero before a held saved17 read cannot override fresh resume after focus", async ({ page, catalog }) => {
  await mediaHarness(page);
  await login(page, catalog);
  await seedSavedPosition(page, catalog, 17000);
  const gate = await holdProgressRead(page, catalog.videos.adult.id, 1);
  try {
    await watch(page, catalog, "adult");
    expect((await (await gate.response).json()).positionMs).toBe(17000);
    await ready(page);
    expect(await currentTime(page)).toBe(0);
    await page.evaluate(() => {
      window.dispatchEvent(new Event("blur"));
      window.dispatchEvent(new Event("focus"));
    });
    await expect(main(page).getByRole("heading", { name: catalog.videos.adult.title, exact: true })).toBeVisible();
    await ready(page);
    await expect.poll(() => currentTime(page)).toBe(17);
    gate.release();
    await gate.done;
    await expect.poll(() => currentTime(page)).toBe(17);
    const saved = await page.request.get(`${API}/watch/progress/${catalog.videos.adult.id}?profileId=${catalog.profileId}`);
    expect((await saved.json()).positionMs).toBe(17000);
  } finally { gate.release(); }
});

test("repeated early focus preserves a prior intentional zero while replacement progress is held", async ({ page, catalog }) => {
  await mediaHarness(page);
  await login(page, catalog);
  await seedSavedPosition(page, catalog, 17000);
  const gate = await holdProgressRead(page, catalog.videos.adult.id, 2);
  await page.route(`${API}/watch/progress/${catalog.videos.adult.id}*`, (route) =>
    route.request().method() === "PUT" ? route.abort("failed") : route.fallback(),
  );
  try {
    await watch(page, catalog, "adult");
    await ready(page);
    await expect.poll(() => currentTime(page)).toBe(17);
    await page.locator(`[data-tv-focus-id="player-seek-${catalog.videos.adult.id}"]`).focus();
    await page.keyboard.press("Home");
    await expect.poll(() => currentTime(page)).toBe(0);
    await page.evaluate(() => {
      window.dispatchEvent(new Event("blur"));
      window.dispatchEvent(new Event("focus"));
    });
    expect((await (await gate.response).json()).positionMs).toBe(17000);
    // The replacement has not received metadata or its resume response. Its
    // default zero is not allowed to erase the retained explicit zero's intent.
    await expect.poll(() => page.locator("video:visible").evaluate((video: HTMLVideoElement) => video.readyState)).toBe(0);
    await page.evaluate(() => {
      window.dispatchEvent(new Event("blur"));
      window.dispatchEvent(new Event("focus"));
    });
    await expect(main(page).getByRole("heading", { name: catalog.videos.adult.title, exact: true })).toBeVisible();
    await ready(page);
    await expect.poll(() => currentTime(page)).toBe(0);
    gate.release();
    await gate.done;
    await expect.poll(() => currentTime(page)).toBe(0);
    const saved = await page.request.get(`${API}/watch/progress/${catalog.videos.adult.id}?profileId=${catalog.profileId}`);
    expect((await saved.json()).positionMs).toBe(17000);
  } finally { gate.release(); }
});
